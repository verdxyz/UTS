<?= $this -> extend('layout')?>
<?= $this -> section('content')?>
ini halaman FAQ
<?= $this -> endSection()?>
